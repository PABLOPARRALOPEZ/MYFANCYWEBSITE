$("#nav").children().css({"color": "white", "background-color": "#145"});

document.getElementById("myInput").placeholder='Pablo';